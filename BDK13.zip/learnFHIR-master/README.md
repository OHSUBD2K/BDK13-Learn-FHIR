# LearnFHIR

## Installation

This webpage is built using Meteor. To clone this project and run it locally, you must first install Meteor from Meteor.com.

## Running

Once you have installed Meteor and cloned the project, simply go to the directory `cd learnFHIR` and type `meteor`.
