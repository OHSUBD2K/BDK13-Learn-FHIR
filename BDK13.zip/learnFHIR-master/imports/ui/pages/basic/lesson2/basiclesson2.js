import { Template } from 'meteor/templating'

import './basiclesson2.html'