import { Template } from 'meteor/templating'

import './footer.html'
