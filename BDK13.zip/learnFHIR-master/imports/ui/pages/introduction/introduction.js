import { Template } from 'meteor/templating'

import './introduction.html'