import { Meteor } from 'meteor/meteor'
import { Links } from './links.js';

Meteor.methods({
  'links.insert'(tweet) {

    // return Links.insert({
    //   url,
    //   title,
    //   createdAt: new Date(),
    // })
  },
})
