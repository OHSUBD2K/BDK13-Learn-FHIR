import { Template } from 'meteor/templating'

import './advancedlesson2.html'