import { Template } from 'meteor/templating'

import './advancedhandson.html'