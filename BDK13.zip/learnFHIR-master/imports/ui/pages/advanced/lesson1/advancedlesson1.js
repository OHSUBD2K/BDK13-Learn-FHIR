import { Template } from 'meteor/templating'

import './advancedlesson1.html'