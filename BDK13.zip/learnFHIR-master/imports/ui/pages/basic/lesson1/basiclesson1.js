import { Template } from 'meteor/templating'

import './basiclesson1.html'