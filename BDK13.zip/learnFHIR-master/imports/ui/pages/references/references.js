import { Template } from 'meteor/templating'

import './references.html'