// Import client startup through a single index entry point

import './routes.js'
import './shareit_config.js'
