import { Template } from 'meteor/templating'

import './prequiz.html'